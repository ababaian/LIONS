Edits that were necessary to parse these files:

23.vcf: change
##INFO=<ID=MQ0Fraction,Number=1,Type=Integer,Description="Fraction of Mapping Quality Zero Reads">
to
##INFO=<ID=MQ0Fraction,Number=1,Type=Float,Description="Fraction of Mapping Quality Zero Reads">

similar changes in 16.vcf and 2.vcf

13.vcf
Flag should not have a value.
