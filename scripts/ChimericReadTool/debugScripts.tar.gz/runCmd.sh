#!/bin/bash

#/home/artem/Desktop/LIONS_fork/bin/python3 /home/artem/Desktop/LIONS_fork/scripts/ChimericReadTool/chimericReadSearch.py /home/artem/Desktop/LIONS_fork/projects/colon/587294/resources/assembly_exons_2 /home/artem/Desktop/LIONS_fork/resources/hg19r/repeat/forChimericSearch 587294.bam tmp.bed > /home/artem/Desktop/LIONS_fork/projects/colon/587294/chimericReadSearch.out

# Grep Search for the MSD LTR: 6248331
# totaGrep.output

# Total Run
#/home/artem/Desktop/LIONS_fork/bin/python3 chimericReadSearch.py assembly_exons_2 forChimericSearch 587294.bam tmp.bed > totalChimSearch_fixed.output
# assembly_exons_2
# forChimericSearch
# 587294.bam 
# tmp.bed




# > ChimSearch.output_TotalRun
# Ratio = 114:256
#587294.21931:587294.21931.1	2	MSTD:LTR:ERVL-MaLR	chr9:6241684-6248575	Down	Yes	587294.21931.2:1	0	0	2	0	2	9	6241684	6241785	6248331	6248575	1	+	2	6215641	6215852	114	256	2
#587294.21931:587294.21931.2	4	MSTD:LTR:ERVL-MaLR	chr9:6248331-6252991	Up	Yes	587294.21931.2:1	0	0	19	0	19	9	6252866	6252991	6248331	6248575	1	+	-1	6251140	6251265	114	256	2
#587294.21931:587294.21931.1	1	MSTD:LTR:ERVL-MaLR	chr9:6215641-6248575	Down	Yes	587294.21931.2:1	0	0	1	0	1	9	6215641	6215852	6248331	6248575	1	+	2	6215641	6215852	114	256	2
#587294.21931:587294.21931.2	1	MSTD:LTR:ERVL-MaLR	chr9:6248331-6248575	EInside	Yes	587294.21931.2:1	0	0	0	28	28	9	6248424	6248555	6248331	6248575	1	+	-1	6248424	6248555	114	256	2
#587294.21931:587294.21931.1	3	MSTD:LTR:ERVL-MaLR	chr9:6248331-6250599	Up	Yes	587294.21931.2:1	0	0	50	0	50	9	6250474	6250599	6248331	6248575	1	+	2	6241684	6241785	114	256	2
#587294.21931:587294.21931.2	3	MSTD:LTR:ERVL-MaLR	chr9:6248331-6251265	Up	Yes	587294.21931.2:1	0	0	88	0	88	9	6251140	6251265	6248331	6248575	1	+	-1	6250474	6250599	114	256	2


# Chr 9 extract
# samtools view -bh 587294.bam chr9:6148331-6348331 > hr9ex.bam

#/home/artem/Desktop/LIONS_fork/bin/python3 chimericReadSearch.py assembly_exons_2 forChimericSearch chr9ex.bam tmp.bed > chr9_extract.output


#/home/artem/Desktop/LIONS_fork/bin/python3 chimericReadSearch.py assembly_exons_2 forChimericSearch chr9ex.bam tmp.bed > chr9_extract.output



samtools view -bh 587294.bam chr4:128957528-128958761 > hr4_alusx.bam
